<?php // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' ); ?>
<div id="submenu-box">
	<div class="t">
		<div class="t">
			<div class="t"></div>
		</div>
	</div>
	<div class="m">
		<?php echo $this->loadTemplate('navigation') ?>
	</div>
	<div class="b">
		<div class="b">
			<div class="b"></div>
		</div>
	</div>
</div>