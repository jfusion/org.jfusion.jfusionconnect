<?php // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' ); ?>

<div class="submenu-box">
	<div class="submenu-pad">
		<ul id="submenu" class="configuration">
			<li><a href="#" onclick="return false;" id="site" class="active"><?php echo JText::_('OPENID'); ?></a></li>
			<li><a href="#" onclick="return false;" id="system"><?php echo JText::_('RESPONCE'); ?></a></li>
			<li><a href="#" onclick="return false;" id="user"><?php echo JText::_('USERSETTINGS'); ?></a></li>
		</ul>
		<div class="clr"></div>
	</div>
</div>
<div class="clr"></div>
